import Banner from "components/Banner/Banner";
import Card from "components/Card/Card";
import EditarVideoModal from "components/EditarVideoModal/EditarVideoModal";
import styles from "./inicio.module.css";


import { useEffect, useMemo, useState } from "react";

// Constantes fuera de la función
const categorias = ["Backend", "FrontEnd", "Innovación y Gestión"];
const categoriaColores = {
    Backend: "#ff5733",
    FrontEnd: "#33c3ff",
    "Innovación y Gestión": "#66b32f"
};

function Inicio() {
    const [videos, setVideos] = useState([]);

    // useEffect(() => {
    //     fetch("https://my-json-server.typicode.com/thanzel/data-aluraflix-api/videos")
    //         .then((response) => response.json())
    //         .then((data) => {
    //             console.log("data" , data); 
    //             setVideos((data));
    //         });
    // }, []);

    useEffect(() => {
        const fetchVideos = async () => {
            try {
                const response = await fetch("https://my-json-server.typicode.com/thanzel/data-aluraflix-api/videos");
                const data = await response.json();
                setVideos(data);
            } catch (error) {
                console.error("Error al cargar los videos", error);
            }
        };

        fetchVideos();
    }, []);

    // const [videos, setVideos] = useState(videosData);
    const [videoEditado, setVideoEditado] = useState(null);
    const [modalAbierto, setModalAbierto] = useState(false);

    const handleBorrar = (id) => {
        const videosActualizados = videos.filter(video => video.id !== id);
        setVideos(videosActualizados);
    };

    const handleEditar = (id) => {
        const videoSeleccionado = videos.find(video => video.id === id);
        setVideoEditado(videoSeleccionado);
        setModalAbierto(true);
    };

    const handleGuardarEdicion = (id, titulo, categoria, imagen, descripcion) => {
        const videosActualizados = videos.map(video => {
            if (video.id === id) {
                return { ...video, titulo, categoria, imagen, descripcion };
            }
            return video;
        });
        setVideos(videosActualizados);
        setModalAbierto(false);
        setVideoEditado(null);
    };

    const cerrarModal = () => {
        setModalAbierto(false);
        setVideoEditado(null);
    };



    const groupedVideos = useMemo(() => {
        return videos.reduce((acc, { categoria, ...video }) => {
            acc[categoria] = acc[categoria] || [];
            acc[categoria].push({ ...video, id: video.id });
            return acc;
        }, {});
    }, [videos]);


    return (
        <>
             {videos.length > 0 &&  <Banner videos={videos} img="Main" color="#154580" />}

            <EditarVideoModal
                videoEditado={videoEditado}
                categorias={categorias}
                modalAbierto={modalAbierto}
                cerrarModal={cerrarModal}
                handleGuardarEdicion={handleGuardarEdicion}
            />

            {Object.entries(groupedVideos).map(([categoria, videosPorCategoria]) => (
                <div key={categoria}>
                    <h2 className={styles.categoriaTitulo} style={{ backgroundColor: categoriaColores[categoria] }}>
                        {categoria}
                    </h2>
                    <section className={styles.container}>
                        {videosPorCategoria.map(video => (
                            <Card
                                {...video}
                                key={video.id}
                                onDelete={handleBorrar}
                                onEdit={handleEditar}
                            />
                        ))}
                    </section>
                </div>
            ))}
        </>
    );
}

export default Inicio;
