import { useState } from "react";
import { TextField, Button, Select, MenuItem, FormControl, InputLabel, Grid } from "@mui/material";
import styles from "./NuevoVideo.module.css";

const categorias = ["Backend", "FrontEnd", "Innovación y Gestión"];

function NuevoVideo() {
    const [titulo, setTitulo] = useState("");
    const [categoria, setCategoria] = useState("");
    const [imagen, setImagen] = useState("");
    const [link, setLink] = useState("");
    const [descripcion, setDescripcion] = useState("");

    const handleSubmit = (e) => {
        e.preventDefault();
        const nuevoVideo = {
            id: Date.now(),
            titulo,
            categoria,
            imagen,
            link,
            descripcion
        };
        console.log("Nuevo Video Añadido:", nuevoVideo);
        alert("Video añadido con éxito");
        setTitulo("");
        setCategoria("");
        setImagen("");
        setLink("");
        setDescripcion("");
    };

    // const handleCancel = () => {
    //     navigate("/");
    // };

    return (
        <form className={styles.formulario} onSubmit={handleSubmit}>
            <h2>Nuevo Video</h2>
            <Grid container spacing={2}>
                <Grid item xs={6}>
                    <TextField 
                        label="Título" 
                        value={titulo} 
                        onChange={(e) => setTitulo(e.target.value)} 
                        fullWidth 
                        required
                        sx={{
                            '& .MuiInputBase-input': {
                                color: 'white', // Cambia el color del texto a blanco
                            },
                            '& .MuiInputLabel-root': {
                                color: 'white', // Cambia el color del label a blanco
                            },
                            '& .MuiInputLabel-root.Mui-focused': {
                                color: 'white', // Asegura que el label se quede blanco cuando el campo está enfocado
                            },
                            "& .MuiOutlinedInput-notchedOutline": {
                                borderColor: "blue",
                                borderWidth: "2px"
                            },
                            "&:hover .MuiOutlinedInput-notchedOutline": {
                                borderColor: "darkblue"
                            },
                            "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline": {
                                borderColor: "blue",
                                borderWidth: "2px"
                            }
                        }}
                    />
                </Grid>
                <Grid item xs={6}>
                    <FormControl fullWidth required>
                        <InputLabel            htmlFor="categoria"
                                sx={{
                                    color: 'white', // Cambia el color del título a blanco
                                    '&.Mui-focused': {
                                        color: 'white', // Cambia el color del título cuando está enfocado
                                    },
                                }}>
                        
                        Categoría</InputLabel>
                        <Select
                            value={categoria}
                            onChange={(e) => setCategoria(e.target.value)}
                        >
                            {categorias.map((cat, index) => (
                                <MenuItem key={index} value={cat}>{cat}</MenuItem>
                            ))}
                        </Select>
                    </FormControl>
                </Grid>
                <Grid item xs={6}>
                    <TextField 
                        label="Imagen (URL)" 
                        value={imagen} 
                        onChange={(e) => setImagen(e.target.value)} 
                        fullWidth 
                        required
                        sx={{
                            '& .MuiInputBase-input': {
                                color: 'white', // Cambia el color del texto a blanco
                            },
                            '& .MuiInputLabel-root': {
                                color: 'white', // Cambia el color del label a blanco
                            },
                            '& .MuiInputLabel-root.Mui-focused': {
                                color: 'white', // Asegura que el label se quede blanco cuando el campo está enfocado
                            },
                            "& .MuiOutlinedInput-notchedOutline": {
                                borderColor: "blue",
                                borderWidth: "2px"
                            },
                            "&:hover .MuiOutlinedInput-notchedOutline": {
                                borderColor: "darkblue"
                            },
                            "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline": {
                                borderColor: "blue",
                                borderWidth: "2px"
                            }
                        }}
                    />
                </Grid>
                <Grid item xs={6}>
                    <TextField 
                        label="Link del Video" 
                        value={link} 
                        onChange={(e) => setLink(e.target.value)} 
                        fullWidth 
                        required
                        sx={{
                            '& .MuiInputBase-input': {
                                color: 'white', // Cambia el color del texto a blanco
                            },
                            '& .MuiInputLabel-root': {
                                color: 'white', // Cambia el color del label a blanco
                            },
                            '& .MuiInputLabel-root.Mui-focused': {
                                color: 'white', // Asegura que el label se quede blanco cuando el campo está enfocado
                            },
                            "& .MuiOutlinedInput-notchedOutline": {
                                borderColor: "blue",
                                borderWidth: "2px"
                            },
                            "&:hover .MuiOutlinedInput-notchedOutline": {
                                borderColor: "darkblue"
                            },
                            "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline": {
                                borderColor: "blue",
                                borderWidth: "2px"
                            }
                        }}
                    />
                </Grid>
                <Grid item xs={12}>
                    <TextField 
                        label="Descripción" 
                        value={descripcion} 
                        onChange={(e) => setDescripcion(e.target.value)} 
                        multiline 
                        rows={4} 
                        fullWidth 
                        required
                        sx={{
                            '& .MuiInputBase-input': {
                                color: 'white', // Cambia el color del texto a blanco
                            },
                            '& .MuiInputLabel-root': {
                                color: 'white', // Cambia el color del label a blanco
                            },
                            '& .MuiInputLabel-root.Mui-focused': {
                                color: 'white', // Asegura que el label se quede blanco cuando el campo está enfocado
                            },
                            "& .MuiOutlinedInput-notchedOutline": {
                                borderColor: "blue",
                                borderWidth: "2px"
                            },
                            "&:hover .MuiOutlinedInput-notchedOutline": {
                                borderColor: "darkblue"
                            },
                            "& .MuiOutlinedInput-root.Mui-focused .MuiOutlinedInput-notchedOutline": {
                                borderColor: "blue",
                                borderWidth: "2px"
                            }
                        }}
                    />
                </Grid>
                <Grid item xs={12}>
                    <Button variant="contained" color="primary" type="submit">
                        Guardar
                    </Button>
                    {/* <Button variant="outlined" color="secondary" onClick={handleCancel} style={{ marginLeft: "10px" }}>
                        Cancelar
                    </Button> */}
                </Grid>
            </Grid>
        </form>
    );
}

export default NuevoVideo;