import Cabecera from "components/Cabecera/Cabecera"
import Container from "components/Container/Container"
import Pie from "components/Pie/Pie"
import { Outlet } from "react-router-dom"

function PaginaBase() {
    return (
        <main style={{ display: 'flex', flexDirection: 'column', minHeight: '100vh' }}>
            <Cabecera />
            <Container style={{ flex: '1' }}>
                <Outlet />
            </Container>
            <Pie />
        </main>
    )
}
export default PaginaBase
