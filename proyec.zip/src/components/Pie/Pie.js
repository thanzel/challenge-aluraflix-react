import styles from "./Pie.module.css"
import logo from "./LogoMain.png"

function Pie() {
    return (<footer className={styles.container}>
        <img src={logo} alt="Logo AluraFlix" className={styles.img}/>
        {/* <p>Desarrollado por: YCH</p> */}
    </footer>)

}
export default Pie